package com.andorid.stiki.mypoints.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.andorid.stiki.mypoints.R;

public class HomeFragment extends Fragment {
//    private FragmentManager fragmentManager;
//    private Fragment fragmentActive, fragmentHome, fragmentHistory, fragmentProfile;
//
//    private BottomNavigationView bottomNavigationView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //        fragmentManager = getSupportFragmentManager();
//        fragmentHome = new HomeFragment();
//        fragmentHistory = new HistoryFragment();
//        fragmentProfile = new ProfileFragment();
//        fragmentActive = fragmentHome;
//
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//
//        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
//        fragmentManager.beginTransaction().add(R.id.frameLayoutForFragment, fragmentProfile, "Profil").hide(fragmentProfile).commit();
//        fragmentManager.beginTransaction().add(R.id.frameLayoutForFragment, fragmentHistory, "Riwayat").hide(fragmentHistory).commit();
//        fragmentManager.beginTransaction().add(R.id.frameLayoutForFragment, fragmentHome, "Beranda").commit();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        return view;
    }

    //
//    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
//            = new BottomNavigationView.OnNavigationItemSelectedListener() {
//
//        @Override
//        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//            switch (item.getItemId()) {
//                case R.id.home_menu:
//                    setTitle("Beranda");
//                    fragmentManager.beginTransaction().hide(fragmentActive).show(fragmentHome).commit();
//                    fragmentActive = fragmentHome;
////                    doubleBackToExit = true;
//                    return true;
//                case R.id.history_menu:
//                    setTitle("Riwayat");
//                    fragmentManager.beginTransaction().hide(fragmentActive).show(fragmentHistory).commit();
//                    fragmentActive = fragmentHistory;
////                    doubleBackToExit = false;
//                    return true;
//                case R.id.profile_menu:
//                    setTitle("Profil");
//                    fragmentManager.beginTransaction().hide(fragmentActive).show(fragmentProfile).commit();
//                    fragmentActive = fragmentProfile;
////                    doubleBackToExit = false;
//                    return true;
//            }
//            return false;
//        }
//    };
}