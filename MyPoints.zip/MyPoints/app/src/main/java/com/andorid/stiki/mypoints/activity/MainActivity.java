package com.andorid.stiki.mypoints.activity;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.andorid.stiki.mypoints.R;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private CardView cardViewAddPoint, cardViewEventList, cardViewInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        cardViewAddPoint = findViewById(R.id.cardViewAddPoint);
        cardViewEventList = findViewById(R.id.cardViewEventList);
        cardViewInformation = findViewById(R.id.cardViewInformation);

        setSupportActionBar(toolbar);

        cardViewAddPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "cardViewAddPoint", Toast.LENGTH_SHORT).show();
            }
        });
        cardViewEventList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "cardViewEventList", Toast.LENGTH_SHORT).show();
            }
        });
        cardViewInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "cardViewInformation", Toast.LENGTH_SHORT).show();
            }
        });
    }
}